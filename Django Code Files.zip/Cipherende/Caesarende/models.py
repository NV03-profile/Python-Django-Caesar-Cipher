from django.db import models
from django import forms

# Create your models here.
class cipher_text(models.Model):
    Text=models.CharField(max_length=150)
    Key=models.IntegerField()
class cipher_Form(forms.ModelForm):
    class Meta:
        model=cipher_text
        exclude=()

