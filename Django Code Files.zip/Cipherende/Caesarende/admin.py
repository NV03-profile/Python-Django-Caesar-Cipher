from django.contrib import admin
from Caesarende import models
# Register your models here.
class cipherAdmin(admin.ModelAdmin):
    list_display=['Text','Key']
admin.site.register(models.cipher_text,cipherAdmin)
