from django.apps import AppConfig


class CaesarendeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Caesarende'
