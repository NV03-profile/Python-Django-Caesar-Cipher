from django.http import HttpResponse,HttpRequest,HttpResponseRedirect
from django.template import loader
from .models import *
from django.shortcuts import render
# Create your views here.

def encrypt(text,key):
    ct=""
    for char in text:
        if char.isalpha():
            s=ord(char)+key                #encryption=(x+n)mod26
            if char.isupper():
                if s>ord('Z'):
                    s=s-26
                enc=chr(s)
            else:
                #if char.islower():
                if s>ord('z'):
                    s=s-26
                enc=chr(s)
            ct=ct+enc
        else:
            ct=ct+char
    return ct
#g=encrypt(text,key)
#print("Encrypted Text:",g)

def decrypt(ct,key):
    pt=""
    for char in ct:
        if char.isalpha():
            s=ord(char)-key                #decryption=(x-n)mod26
            if char.isupper():
                if s<ord('A'):
                    s=s+26
                dec=chr(s)
            else:
                if s<ord('a'):
                    s=s+26
                dec=chr(s)
            pt=pt+dec
        else:
            pt=pt+char
    return pt
#d=decrypt(c,key)
#print("Decrypted Text:",d)
'''
def home(request):
    res=0
    result=0
    try:
        t=request.GET.get('Txt')
        k=int(request.GET.get('Ke'))
        g=encrypt(t,k)
        y=decrypt(g,k)
        res=g
        result=y
    except:
        pass
    return render(request,"home.html",{'output':res,'op':result})
'''
def home(request):
    t=''
    k=''
    res=''
    result=''
    try:
        if request.method=="POST":
            t=request.POST.get('Txt')
            k=int(request.POST.get('Ke'))
            g=encrypt(t,k)
            y=decrypt(g,k)
            res=g
            result=y
    except:
        pass
    return render(request,"home.html",{'t':t,'k':k,'output':res,'op':result})
